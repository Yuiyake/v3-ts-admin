import { createBrowserHistory } from 'history'

const history = createBrowserHistory()

export { history }